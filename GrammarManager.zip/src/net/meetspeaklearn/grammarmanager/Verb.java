/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.meetspeaklearn.grammarmanager;

/**
 *
 * @author steve
 */
public class Verb extends PartOfSpeech {
    
    public Verb() {
        goClass = GrammarObject.GO_CLASS.VERB;
    }
    
}
